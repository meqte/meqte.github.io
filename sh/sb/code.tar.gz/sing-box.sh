#!/bin/bash

args=$@
is_sh_ver=v1.14

. /etc/sing-box/sh/src/init.sh