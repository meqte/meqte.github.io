#!/bin/bash

args=$@
is_sh_ver=v2026.01.01

. /etc/sing-box/sh/src/init.sh